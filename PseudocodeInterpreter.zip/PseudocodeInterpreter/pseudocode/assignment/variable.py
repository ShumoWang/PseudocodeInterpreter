print('Variable module successfully imported. ')
    

class Var:
    def __init__(self, name: str, type: str):
        self.name = name
        if type not in ['STR', 'INT', 'BOO']:
            raise TypeError(f'Unknown type: {type}.')
        self.type = type
        self.__value = None
    
    def __add__(self, other):
        return self.__value + other.__value
    
    def __sub__(self, other):
        return self.__value - other.__value
    
    def __mul__(self, other):
        return self.__value * other.__value
    
    def __div__(self, other):
        return self.__value / other.__value
    
    def __eq__(self, other):
        return self.__value == other.__value
    
    def __gt__(self, other):
        return self.__value > other.__value
    
    def __ge__(self, other):
        return self.__value >= other.__value
    
    def SetValue(self, value: str):
        if self.type == 'STR':
            self.__value = value
        elif self.type == 'INT':
            self.__value = int(value)
        else:
            if value == 'TRUE':
                self.__value = True
            elif value == 'FALSE':
                self.__value = False
            else:
                raise ValueError('Assign __value not boolean.')

    def GetValue(self):
        return self.__value    


class Array:
    def __init__(self, name, range: int):
        self.name = name
        self.__value = list(' ' * range)
    
    def __add__(self, other):
        return self.__value + other.__value
    
    def SetValue(self, position: int, value):
        self.__value[position - 1] = value
    
    def GetValue(self, position: int = None):
        if position == None:
            return self.__value
        return self.__value[position - 1]
    


