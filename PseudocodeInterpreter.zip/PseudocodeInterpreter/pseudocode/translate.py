from pseudocode.assignment import variable
print('Translate module successfully imported. ')


def SetVar(varList: list, name_value: list, position = None) -> list:
    if position == None:
        for i in varList:
            if i.name == name_value[0]:                
                i.SetValue(findValue(findArith(name_value[1], varList), varList))
                break
        else:
            raise NameError(f'Variable {name_value[0]} is not declared. ')
        return varList
    else:
        for i in varList:
            if i.name == name_value[0][:name_value[0].index('[')]:
                i.SetValue(position, findValue(findArith(name_value[1], varList), varList))
                break                
        else:
            raise NameError(f'Variable {name_value[0]} is not declared. ')
        return varList


def findValue(object, varList: list):
    object = str(object)
    if object[0] == "\"":
        return object
    elif object.isnumeric() == True:
        return int(object)
    elif object == 'TRUE':
        return True
    elif object == 'FALSE':
        return False
    else:
        if "[" in object:
            name = object[:object.index('[')]
            position = int(object[object.index('[') + 1:object.index(']')])
            for i in varList:
                if i.name == name:
                    return i.GetValue(position)
            else:
                raise NameError(f'{object} is not defined. ')
        else:
            for i in varList:
                if i.name == object:
                    return i.GetValue()
            else:
                raise NameError(f'{object} is not defined. ')


def findLogic(code: str, varList: list) -> bool:
    expressions = ['>=', '<=', '<>', '=', '>', '<']
    for i in expressions:
        if i in code:
            type = i
            break
    if 'NOT' in code:
        edit_code = code[3:]
    else:
        edit_code = code
    two_values = edit_code.split(type)
    if type == '=':
        type = '=='
    if type == '<>':
        type = '!='
    value1 = findValue(findArith(two_values[0], varList), varList)
    value2 = findValue(findArith(two_values[1], varList), varList)
    result = eval(f"{value1}{type}{value2}")
    if 'NOT' in code:
        return not result
    else:
        return result


def findCompare(code: str, varList: list):
    if "AND" in code:
        statements = code.split('AND')
        value = True
        for i in statements:
            if 'NOT' in i:
                result = (not findValue(findArith(i[3:], varList), varList)) and value
            else:
                result = findValue(findArith(i, varList), varList) and value
            value = result
        return result
    elif "OR" in code:
        statements = code.split('OR')
        value = True
        for i in statements:
            if 'NOT' in i:
                result = (not findValue(findArith(i[3:], varList), varList)) or value
            else:
                result = findValue(findArith(i, varList), varList) or value
            value = result
        return result
    else:
        return not findValue(code[3:], varList)


def findArith(expression: str, varList: list):
    if any(i in expression for i in ['+', '-', '*', '/', 'MOD', 'DIV']):
        import re
        expression = expression.replace("MOD", "%")
        expression = expression.replace("DIV", "//")
        objects = re.findall(r'"[^"]+"|\w+', expression)
        for i in objects:
            value = findValue(i, varList)
            expression = expression.replace(i, str(value))
        ans = str(eval(expression))
        if ans.isnumeric():
            return int(ans)
        else:
            return f'"{ans}"'
    else:
        return expression

            
def checkif(statement, varList):
    if any(i in statement for i in ['=', '>', '<']):
        if "AND" in statement:
            statements = statement.split('AND')
            value = findLogic(statements[0], varList)
            for i in statements:
                result = findLogic(i, varList) and value
                value = result
            return result
        elif "OR" in statement:
            statements = statement.split('OR')
            value = findLogic(statements[0], varList)
            for i in statements:
                result = findLogic(i, varList) or value
                value = result
            return result
        else:
            return findLogic(statement, varList)
    elif any(i in statement for i in ['AND', 'OR', 'NOT']):
        return findCompare(statement, varList)


def translate(varList: list, code: str, isExecute: bool, ifBool: bool):
    code = code.replace(" ", "")
    if code == 'ENDIF':
        return True, varList, False
    elif "IF" in code and "ELSE" not in code:
        statement = code[2:].replace('THEN', '')
        result = checkif(statement, varList)
        if not result:
            return False, varList, False
        else:
            return True, varList, True
    elif "ELSEIF" in code:
        statement = code[6:].replace('THEN', '')
        if not isExecute and not ifBool:
            result = checkif(statement, varList)
            if result:
                return True, varList, True
            else:
                return False, varList, False
        return False, varList, True
    elif "ELSE" in code:
        if not isExecute and not ifBool:
            return True, varList, True
        return False, varList, False
    elif "DECLARE" in code:
        type = code[-3:]
        if type == "ARR":
            name = ''
            for i in code[7:]:
                if i != "[":
                    name += i
                else:
                    index = code.index(i)
                    break
            range = ''
            for i in code[index + 3:]:
                if i != "]":
                    range += i
                else:
                    break
            varList.append(variable.Array(name, int(range)))
        else:
            name = ''
            for i in code[7:]:
                if i != ":":
                    name += i
                else:
                    break
            varList.append(variable.Var(name, type))
    elif "<-" in code:
        name_value = code.split('<-')
        if "[" in name_value[0]:
            position = int(name_value[0][name_value[0].index('[') + 1:name_value[0].index(']')])
            varList = SetVar(varList, name_value, position)
        else:
            varList = SetVar(varList, name_value)
    elif "OUTPUT" in code:
        object = code[6:]
        if "," in object:
            objects = object.split(",")
            result = ""
            for i in objects:
                result += str(findValue(findArith(i, varList), varList))
            print(result.replace("\"", ""))
        else:
            print(str(findValue(findArith(object, varList), varList)).replace("\"", ""))
    elif any(i in code for i in ['=', '>', '<']):
        if "AND" in code:
            statements = code.split('AND')
            value = findLogic(statements[0], varList)
            for i in statements:
                result = findLogic(i, varList) and value
                value = result
            print(result)
        elif "OR" in code:
            statements = code.split('OR')
            value = findLogic(statements[0], varList)
            for i in statements:
                result = findLogic(i, varList) or value
                value = result
        else:
            print(findLogic(code, varList))
    elif any(i in code for i in ['AND', 'OR', 'NOT']):
        print(findCompare(code, varList))
    elif code == 'exit':
        return False, varList, False
    else:
        raise SyntaxError('Unkown syntax. ')
    return True, varList, False