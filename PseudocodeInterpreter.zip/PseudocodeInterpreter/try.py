from pseudocode import translate
# isExit = True
# varList = []
# while isExit:
#     try:
#         isExit, varList = translate.translate(varList, input('>>> '))
#     except Exception as e:
#         print(e)
varList = []
isExecute = True
ifBool = False
indentation = 0
with open('pseudocode.txt', 'r') as f:
    Lines = f.readlines()
try:
    for i in Lines:
        if "END" in i:
            indentation -= 1
        elif "IF" in i:
            indentation += 1
        if not isExecute and indentation != 0 and not any(x in i for x in ['END', 'ELSE']):
            continue
        isExecute, varList, ifBool = translate.translate(varList, i.replace("\n", "").replace("\t", ""), isExecute, ifBool)
except Exception as e:
    print(e)


